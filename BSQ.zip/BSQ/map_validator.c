/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map_validator.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spoernba <spoernba@student.42vienna.c      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/31 16:18:36 by spoernba          #+#    #+#             */
/*   Updated: 2026/08/31 18:29:26 by spoernba         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	check_three(char *line, int len)
{
	char	a, b, c;

	a = line[len - 3];
	b = line[len - 2];
	c = line[len - 1];
	if (a < 32 || a > 126 || b < 32 || b > 126 || c < 32 || c > 126)
		return (0);
	if (a == b || b == c || a == c)
		return (0);
	return (1);
}

int	str_len(char *str)
{
	int i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

int	check_first_line(char *line, int *digit)
{
	int	i;
	int	nbr;
	int	len;

	len = str_len(line);
	if (len < 4)
		return (0);
	// check if last 3 different printable chars
	if (!check_three(line, len))
		return (0);
	// if nbr > 9 we need to transform it char by char to int
	i = 0;
	nbr = 0;
	while (i < len - 3)
	{
		if (line[i] < '0' || line[i] > '9')
			return (0);
		nbr = nbr * 10 + (line[i] - '0');
		i++;
	}
	*digit = nbr;
	return (1);
}

int check_map_lines(int nbr, char **map, char a, char b, char c)
{
	int	i;
	int j;
	int	linelen;

	i = 1;
	//check number of lines equals to input number
	while (map[i])
		i++;
	if (i - 1 != nbr)
		return (0);
	//check if each len of each line is the same
	// check if chars are used in map
	linelen =  str_len(map[1]);
	i = 2;
	while(i <= nbr)
	{
		j = 0;
		while (map[i][j])
		{
			if (map[i][j] != a && map[i][j] != b)
				return (0);
			j++;
		}
		if (j != str_len)
			return (0);
		i++;
	}
	return (1);
}

int	map_validator(char **map)
{
	int nbr;

	//calls the above functions
	if (!check_first_line(map[0], &nbr))
		return (0);
	// but how to get nbr from check first line?
	if (!check_map_lines(nbr, map))
		return (0);
	return (1);
}